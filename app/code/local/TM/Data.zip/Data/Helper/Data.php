<?php
class TM_Data_Helper_Data extends Mage_Core_Helper_Abstract {

    const CAT_DEFAULT_ID = 2;
    const CAT_VEGETABLE_ID = 3;
    const CAT_MEAL_ID = 4;
    const CAT_FRUIT_ID = 5;
    const CAT_RICE_ID = 6;
    const CAT_SPECIALTIES_ID = 7;
    const CAT_OTHERS_ID = 8;
    const CAT_VEGETABLE_SLUG = 'vegetable';
    const CAT_MEAL_SLUG = 'meal';
    const CAT_FRUIT_SLUG = 'fruit';
    const CAT_RICE_SLUG = 'rice';
    const CAT_SPECIALTIES_SLUG = 'specialties';
    const CAT_OTHERS_SLUG = 'others';


}